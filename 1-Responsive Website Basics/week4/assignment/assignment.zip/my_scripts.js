	function myHelpFunction() {
	  document.getElementById("liveText").innerHTML = "Click on the photos above for larger photo and product details.";
	}
